##    
   第一个React项目实战，弄了一周的成果 o(∩_∩)o  下面是效果图

   ![github](http://movejs-10002597.file.myqcloud.com/music/2.jpg?sign=zOQ00IMMtzkyUEf2flIUjoIGZRZhPTEwMDAyNTk3Jms9QUtJRHo4WFo4dFdEWmNOOTUwSXVWZTlEVU5FN2xlVHhDdlZPJmU9MTQ2MzQ3OTcxOSZ0PTE0NjA4ODc3MTkmcj00MjEwNDY3MTUmZj0vbXVzaWMvMi5qcGcmYj1tb3ZlanM= "github")   
     
### Technology  
   React + Nodejs + webpack打包 +PHP AJXA  JS  Css

### 项目在线地址
1.[点击这里查看Demo](http://music.movecss.com/src/template/music.html)<br />
2.[点击这里链接到我的博客](http://www.movecss.com)<br />
 
 